# PGP-CTRL SUMMARY

**Outcome Classification:** OUTCOME C
**Average Interventional Uplift:** -0.0073

We shifted from collapse *prediction* to collapse *intervention*. We applied bounded budgets to harden nodes against cascading failures across Static Fragmentation (R1), Dynamic Capacity Cascades (R2), and Observability Hostility (R3).

## Findings
- **Baseline Dominance:** B6_Greedy and B1_MaxDegree remain highly competitive interventional baselines.
- **Helix Operators:** Evaluated SRD, FHO, OGO independently and combined.
- **Regime Shift:** Targetting centrality for intervention hardens the hub, effectively shielding the standard graph against normal cascade loads, yielding baseline superiority.
