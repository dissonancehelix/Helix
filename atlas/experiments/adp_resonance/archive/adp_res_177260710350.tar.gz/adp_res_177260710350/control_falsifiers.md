# CONTROL FALSIFIERS
- Jitter Injection fails completely if baseline structural noise approaches the injected jitter amplitude.