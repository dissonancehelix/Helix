# FALSIFIERS
- Resonance scaling (X4) falsified if jitter > 50ms does not break the phase lock.
- HYP_2 falsified if Resonance persists stably at redundancy > 0.9.