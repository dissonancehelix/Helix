# ADP RESONANCE SCALING SUMMARY
- Best scaling predictor: X4 = (latency_mean * short_cycle_density) / (jitter_amp + eps)
- Strongest Falsifier: Fails if jitter > 50ms does not snap the cascade.
- Intervention Winner: Targeted Cycle-Break
- Metric Fails: Static PCP fails; tPCP fixes false Fields.