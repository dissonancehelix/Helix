# MEMORY AXIS EXPERIMENTS
- Memory introduces state persistence that directly overrides static structural limits.
- Confirmed HYSTERESIS_FUNNEL: compressions do not cleanly dissolve when physical bottlenecks are removed.
- Confirmed MEMORY_LOCKED_DECISION: memory infinitely suspends resonant loops against noise disruption.
- Shock: Memory can trap random noise in a symmetric field and build a completely synthetic Funnel geometry out of thin air.