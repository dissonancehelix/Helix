# LIP v2 FALSIFIERS
- H-LIP-4 (Immune Fragmentation): Falsified if cycle-breaking in a Fragmented Field reduces global component connectivity without accelerating the critical capacity cascade limit.
- H-LIP-5 (Async Funnel Reversal): Falsified if jitter cleanly disperses an async funnel into a symmetrical field without hitting the central commitment threshold.
- H-LIP-6 (Paradox Trap): Falsified if predictive correlation degrades monotonically uniformly regardless of dropout overlap with semantic proxy nodes.