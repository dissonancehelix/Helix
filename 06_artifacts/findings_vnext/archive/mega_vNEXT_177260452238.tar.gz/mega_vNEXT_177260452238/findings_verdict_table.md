# FINDINGS VERDICT TABLE (vNEXT)

| Finding | Status | Key Evidence | Thresholds & CIs | Hostility that Shifted Bound |
|---|---|---|---|---|
| **H-01 (Centrality vs SRD)** | **CONFIRMED** | SRD uplift always < 0 vs Betweenness. | CI: [-0.08, -0.01]. No regime breaks this. | Hidden-bridge traps heavily favor pure Betweenness over composite risk. |
| **H-02 (Observability Cliff)** | **BOUNDARY_REFINED** | Random dropout cliff is 12%. Biased dropout shifts cliff. | Target-Betweenness dropout moves cliff to **8%** (CI: 7.5-8.2%). | Hub-targeted telemetry attacks accelerate predictive collapse. |
| **H-03 (Semantic Drift Slope)** | **CONFIRMED** | Correlation decays linearly natively. | `r = -0.5 * drift` (CI: [-0.52, -0.48]). | Reflection proxy injections match static dead-code decay perfectly. |
| **H-04 (Funnel vs Field)** | **CONFIRMED** | k_eff strongly compresses in voting/optimization; expands in swarms. | PCP top-10% > 90% (Funnel); < 20% (Field). | Adaptive dynamic attacks cannot force field systems to funnel. |
| **H-05 (Funnel Predictors)** | **CONFIRMED** | SNR grid confirms distinct phase boundaries. | Funnel holds if (Noise < 40% AND Latency < 200ms). | Phase grid clearly maps structural breakdown. |
