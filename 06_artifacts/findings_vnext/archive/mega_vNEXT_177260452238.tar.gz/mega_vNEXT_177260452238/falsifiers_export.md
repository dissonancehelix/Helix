# MEGATEST vNEXT EXPORTED FALSIFIERS

- If a biased dropout attack targeting high-betweenness nodes **does not** shift the observability cliff below 10%, H-02's refinement is falsified.
- If a high-latency (>400ms) centralized graph maintains a Funnel metric (PCP > 90%), H-05's grid map is falsified.
- If directed cascading graphs with active asymmetric recovery rules produce an SRD defender uplift > 0.10, H-01 is falsified.
